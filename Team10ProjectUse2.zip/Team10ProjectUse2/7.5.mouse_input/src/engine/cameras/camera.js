/*
 * File: camera.js
 *
 * Encapsulates the user define WC and Viewport functionality
 */
"use strict";

import Camera from "./camera_input.js";
export default Camera;